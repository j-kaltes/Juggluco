package tk.glucodata

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color.*
import android.graphics.Paint
import android.graphics.Paint.Align
import android.graphics.Path
import android.graphics.Rect
import android.view.SurfaceHolder
import androidx.core.graphics.withScale
import androidx.wear.watchface.*
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.rendering.CanvasComplicationDrawable
import androidx.wear.watchface.complications.rendering.ComplicationDrawable
import androidx.wear.watchface.style.CurrentUserStyleRepository
import androidx.wear.watchface.style.UserStyle
import androidx.wear.watchface.style.UserStyleSetting
import androidx.wear.watchface.style.WatchFaceLayer
import kotlinx.coroutines.*
import tk.glucodata.Applic
import tk.glucodata.Applic.setscreenupdater
import tk.glucodata.Log
import tk.glucodata.Natives
import tk.glucodata.strGlucose
import tk.glucodata.watchface.data.watchface.ColorStyleIdAndResourceIds
import tk.glucodata.watchface.data.watchface.WatchFaceColorPalette.Companion.convertToWatchFaceColorPalette
import tk.glucodata.watchface.data.watchface.WatchFaceData
import tk.glucodata.watchface.utils.COLOR_STYLE_SETTING
import tk.glucodata.watchface.utils.LEFT_AND_RIGHT_COMPLICATIONS_TOP_BOUND
import tk.glucodata.watchface.utils.ratTimebaseY
import java.time.ZonedDateTime
import kotlin.math.pow
import kotlin.math.sqrt

    

    

class CommonCanvas {

    companion object {
        private const val LOG_ID = "CommonCanvas"
private inline fun glnearnull(rate:Float):Boolean = (rate<.8f&&rate>-.8f)

private fun drawarrow(canvas: Canvas,paint:Paint,density:Float, ratein:Float, getx:Float, gety:Float):Boolean {
	if(!ratein.isNaN()) {
		val rate= if(glnearnull(ratein)) .0f else ratein
		val x1:Double= (getx-density*40.0)
		val y1:Double= (gety+rate*density*30.0)

		var rx: Double=getx-x1
		var ry:Double=gety-y1
		val rlen= sqrt(rx.pow(2.0) + ry.pow(2.0))
		 rx/=rlen
		 ry/=rlen

		val l:Double=density*12.0;

		val addx= l* rx;
		val addy= l* ry;
		val tx1=getx-2*addx;
		val ty1=gety-2*addy;
		val xtus:Float= (getx-1.5*addx).toFloat();
		val ytus:Float= (gety-1.5*addy).toFloat();
		val hx=ry;
		val hy=-rx;
		val sx1:Float= (tx1+l*hx).toFloat();
		val sy1:Float= (ty1+l*hy).toFloat();
		val sx2:Float = (tx1-l*hx).toFloat();
		val sy2:Float= (ty1-l*hy).toFloat();
              paint.strokeWidth = density.toFloat()*5.0f
	    canvas.drawLine(x1.toFloat(), y1.toFloat(), xtus, ytus,paint)
		canvas.drawPath(Path().apply {
			moveTo(sx1,sy1) ;
			lineTo(getx,gety);
			lineTo(sx2,sy2);
			lineTo( xtus,ytus);
            		close()
			},paint)
           return true
		}
    return false
	}
@JvmStatic
fun	showglucose(glucosePaint:Paint,agePaint:Paint,density:Float,unixtime:Long,glucose:strGlucose?)  {
                if(glucose!=null) {
		    Log.i(LOG_ID,"glucose=${glucose.value} time=${glucose.time}")
		     var age:Int=(unixtime-glucose.time).toInt()
		     val oldage=(60.0f*3.0f)
		   if(age<oldage) {
			    if(age<0) age=0
			    var getx= width*0.5f
			    val gety= height*0.66f)
			   val rate=glucose.rate
				if(rate.isNaN()) {
					getx=width*0.45f
					}
				else  {
				    drawarrow(this,glucosePaint,density,rate,width*.25f,height*.55f)
				    }
			    drawText(glucose.value,getx,gety, glucosePaint)
			    val idbounds=Rect()
			    glucosePaint.textSize/=5.0f
			    val sensorid=glucose.sensorid
			    glucosePaint.getTextBounds(sensorid, 0,sensorid.length, idbounds)
			    val yid= gety+idbounds.height()*1.5f
			    val wid= idbounds.width()
			    val relage=age*wid/oldage
			    val xage= getx-wid*.5f
			    val hid= idbounds.height()
			    drawRect( xage,yid-hid*1.05f,xage +relage, yid+0.07f*hid,agePaint)
			    drawText(sensorid,getx,yid, glucosePaint)
		 	}
		else {
			Log.i(LOG_ID,"age ($age) >= oldage ($oldage)")
			}
			}

	 	}
    private val glucosePaint = Paint().apply {
        isAntiAlias = true
        textAlign = Align.CENTER
        color = WHITE
    }

    private val timePaint = Paint().apply {
        isAntiAlias = true
        textAlign = Align.CENTER
        color = WHITE
    }
    private val agePaint = Paint().apply {
        setARGB(0xFF,0xFF,0,0xFF)
       }


    }
}
