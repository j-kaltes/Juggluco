package com.garmin.android.connectiq;

import android.os.Parcel;
import android.os.Parcelable;

public class IQMessage implements Parcelable {
    public static final Parcelable.Creator<IQMessage> CREATOR = new Parcelable.Creator<IQMessage>() {
        public IQMessage createFromParcel(Parcel in) {
            return new IQMessage(in);
        }

        public IQMessage[] newArray(int size) {
            return new IQMessage[size];
        }
    };
    public byte[] messageData;
    public String notificationAction;
    public String notificationPackage;

    public IQMessage(byte[] messageData2, String notificationPackage2, String notificationAction2) {
        this.messageData = new byte[messageData2.length];
        System.arraycopy(messageData2, 0, this.messageData, 0, messageData2.length);
        this.notificationPackage = notificationPackage2;
        this.notificationAction = notificationAction2;
    }

    public IQMessage(Parcel in) {
        if (in.readInt() > 0) {
            this.messageData = in.createByteArray();
        }
        this.notificationPackage = in.readString();
        this.notificationAction = in.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        if (this.messageData != null) {
            dest.writeInt(this.messageData.length);
            dest.writeByteArray(this.messageData);
        } else {
            dest.writeInt(0);
        }
        dest.writeString(this.notificationPackage);
        dest.writeString(this.notificationAction);
    }
}
