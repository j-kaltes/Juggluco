package com.garmin.android.apps.connectmobile.connectiq;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.garmin.android.connectiq.IQApp;
import com.garmin.android.connectiq.IQDevice;
import com.garmin.android.connectiq.IQMessage;
import java.util.List;

public interface IConnectIQService extends IInterface {
    void getApplicationInfo(String str, String str2, IQDevice iQDevice, String str3) throws RemoteException;

    List<IQDevice> getConnectedDevices() throws RemoteException;

    List<IQDevice> getKnownDevices() throws RemoteException;

    int getStatus(IQDevice iQDevice) throws RemoteException;

    void openApplication(String str, String str2, IQDevice iQDevice, IQApp iQApp) throws RemoteException;

    boolean openStore(String str) throws RemoteException;

    void registerApp(IQApp iQApp, String str, String str2) throws RemoteException;

    void sendImage(IQMessage iQMessage, IQDevice iQDevice, IQApp iQApp) throws RemoteException;

    void sendMessage(IQMessage iQMessage, IQDevice iQDevice, IQApp iQApp) throws RemoteException;

    public static abstract class Stub extends Binder implements IConnectIQService {
        private static final String DESCRIPTOR = "com.garmin.android.apps.connectmobile.connectiq.IConnectIQService";
        static final int TRANSACTION_getApplicationInfo = 5;
        static final int TRANSACTION_getConnectedDevices = 2;
        static final int TRANSACTION_getKnownDevices = 3;
        static final int TRANSACTION_getStatus = 4;
        static final int TRANSACTION_openApplication = 6;
        static final int TRANSACTION_openStore = 1;
        static final int TRANSACTION_registerApp = 9;
        static final int TRANSACTION_sendImage = 8;
        static final int TRANSACTION_sendMessage = 7;

        public Stub() {
            attachInterface(this, DESCRIPTOR);
        }

        public static IConnectIQService asInterface(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
            if (iin == null || !(iin instanceof IConnectIQService)) {
                return new Proxy(obj);
            }
            return (IConnectIQService) iin;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            IQApp _arg0;
            IQMessage _arg02;
            IQDevice _arg1;
            IQApp _arg2;
            IQMessage _arg03;
            IQDevice _arg12;
            IQApp _arg22;
            IQDevice _arg23;
            IQApp _arg3;
            IQDevice _arg24;
            IQDevice _arg04;
            switch (code) {
                case 1:
                    data.enforceInterface(DESCRIPTOR);
                    boolean _result = openStore(data.readString());
                    reply.writeNoException();
                    reply.writeInt(_result ? 1 : 0);
                    return true;
                case TRANSACTION_getConnectedDevices /*2*/:
                    data.enforceInterface(DESCRIPTOR);
                    List<IQDevice> _result2 = getConnectedDevices();
                    reply.writeNoException();
                    reply.writeTypedList(_result2);
                    return true;
                case TRANSACTION_getKnownDevices /*3*/:
                    data.enforceInterface(DESCRIPTOR);
                    List<IQDevice> _result3 = getKnownDevices();
                    reply.writeNoException();
                    reply.writeTypedList(_result3);
                    return true;
                case TRANSACTION_getStatus /*4*/:
                    data.enforceInterface(DESCRIPTOR);
                    if (data.readInt() != 0) {
                        _arg04 = IQDevice.CREATOR.createFromParcel(data);
                    } else {
                        _arg04 = null;
                    }
                    int _result4 = getStatus(_arg04);
                    reply.writeNoException();
                    reply.writeInt(_result4);
                    return true;
                case TRANSACTION_getApplicationInfo /*5*/:
                    data.enforceInterface(DESCRIPTOR);
                    String _arg05 = data.readString();
                    String _arg13 = data.readString();
                    if (data.readInt() != 0) {
                        _arg24 = IQDevice.CREATOR.createFromParcel(data);
                    } else {
                        _arg24 = null;
                    }
                    getApplicationInfo(_arg05, _arg13, _arg24, data.readString());
                    return true;
                case TRANSACTION_openApplication /*6*/:
                    data.enforceInterface(DESCRIPTOR);
                    String _arg06 = data.readString();
                    String _arg14 = data.readString();
                    if (data.readInt() != 0) {
                        _arg23 = IQDevice.CREATOR.createFromParcel(data);
                    } else {
                        _arg23 = null;
                    }
                    if (data.readInt() != 0) {
                        _arg3 = IQApp.CREATOR.createFromParcel(data);
                    } else {
                        _arg3 = null;
                    }
                    openApplication(_arg06, _arg14, _arg23, _arg3);
                    return true;
                case TRANSACTION_sendMessage /*7*/:
                    data.enforceInterface(DESCRIPTOR);
                    if (data.readInt() != 0) {
                        _arg03 = IQMessage.CREATOR.createFromParcel(data);
                    } else {
                        _arg03 = null;
                    }
                    if (data.readInt() != 0) {
                        _arg12 = IQDevice.CREATOR.createFromParcel(data);
                    } else {
                        _arg12 = null;
                    }
                    if (data.readInt() != 0) {
                        _arg22 = IQApp.CREATOR.createFromParcel(data);
                    } else {
                        _arg22 = null;
                    }
                    sendMessage(_arg03, _arg12, _arg22);
                    return true;
                case TRANSACTION_sendImage /*8*/:
                    data.enforceInterface(DESCRIPTOR);
                    if (data.readInt() != 0) {
                        _arg02 = IQMessage.CREATOR.createFromParcel(data);
                    } else {
                        _arg02 = null;
                    }
                    if (data.readInt() != 0) {
                        _arg1 = IQDevice.CREATOR.createFromParcel(data);
                    } else {
                        _arg1 = null;
                    }
                    if (data.readInt() != 0) {
                        _arg2 = IQApp.CREATOR.createFromParcel(data);
                    } else {
                        _arg2 = null;
                    }
                    sendImage(_arg02, _arg1, _arg2);
                    return true;
                case TRANSACTION_registerApp /*9*/:
                    data.enforceInterface(DESCRIPTOR);
                    if (data.readInt() != 0) {
                        _arg0 = IQApp.CREATOR.createFromParcel(data);
                    } else {
                        _arg0 = null;
                    }
                    registerApp(_arg0, data.readString(), data.readString());
                    return true;
                case 1598968902:
                    reply.writeString(DESCRIPTOR);
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }

        private static class Proxy implements IConnectIQService {
            private IBinder mRemote;

            Proxy(IBinder remote) {
                this.mRemote = remote;
            }

            public IBinder asBinder() {
                return this.mRemote;
            }

            public String getInterfaceDescriptor() {
                return Stub.DESCRIPTOR;
            }

            public boolean openStore(String applicationID) throws RemoteException {
                boolean _result = true;
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(applicationID);
                    this.mRemote.transact(1, _data, _reply, 0);
                    _reply.readException();
                    if (_reply.readInt() == 0) {
                        _result = false;
                    }
                    return _result;
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            public List<IQDevice> getConnectedDevices() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getConnectedDevices, _data, _reply, 0);
                    _reply.readException();
                    return _reply.createTypedArrayList(IQDevice.CREATOR);
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            public List<IQDevice> getKnownDevices() throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    this.mRemote.transact(Stub.TRANSACTION_getKnownDevices, _data, _reply, 0);
                    _reply.readException();
                    return _reply.createTypedArrayList(IQDevice.CREATOR);
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            public int getStatus(IQDevice device) throws RemoteException {
                Parcel _data = Parcel.obtain();
                Parcel _reply = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (device != null) {
                        _data.writeInt(1);
                        device.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    this.mRemote.transact(Stub.TRANSACTION_getStatus, _data, _reply, 0);
                    _reply.readException();
                    return _reply.readInt();
                } finally {
                    _reply.recycle();
                    _data.recycle();
                }
            }

            public void getApplicationInfo(String notificationPackage, String notificationAction, IQDevice device, String applicationID) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(notificationPackage);
                    _data.writeString(notificationAction);
                    if (device != null) {
                        _data.writeInt(1);
                        device.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    _data.writeString(applicationID);
                    this.mRemote.transact(Stub.TRANSACTION_getApplicationInfo, _data, (Parcel) null, 1);
                } finally {
                    _data.recycle();
                }
            }

            public void openApplication(String notificationPackage, String notificationAction, IQDevice device, IQApp app) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    _data.writeString(notificationPackage);
                    _data.writeString(notificationAction);
                    if (device != null) {
                        _data.writeInt(1);
                        device.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    if (app != null) {
                        _data.writeInt(1);
                        app.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    this.mRemote.transact(Stub.TRANSACTION_openApplication, _data, (Parcel) null, 1);
                } finally {
                    _data.recycle();
                }
            }

            public void sendMessage(IQMessage message, IQDevice device, IQApp app) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (message != null) {
                        _data.writeInt(1);
                        message.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    if (device != null) {
                        _data.writeInt(1);
                        device.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    if (app != null) {
                        _data.writeInt(1);
                        app.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    this.mRemote.transact(Stub.TRANSACTION_sendMessage, _data, (Parcel) null, 1);
                } finally {
                    _data.recycle();
                }
            }

            public void sendImage(IQMessage image, IQDevice device, IQApp app) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (image != null) {
                        _data.writeInt(1);
                        image.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    if (device != null) {
                        _data.writeInt(1);
                        device.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    if (app != null) {
                        _data.writeInt(1);
                        app.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    this.mRemote.transact(Stub.TRANSACTION_sendImage, _data, (Parcel) null, 1);
                } finally {
                    _data.recycle();
                }
            }

            public void registerApp(IQApp app, String notificationAction, String notificationPackage) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken(Stub.DESCRIPTOR);
                    if (app != null) {
                        _data.writeInt(1);
                        app.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    _data.writeString(notificationAction);
                    _data.writeString(notificationPackage);
                    this.mRemote.transact(Stub.TRANSACTION_registerApp, _data, (Parcel) null, 1);
                } finally {
                    _data.recycle();
                }
            }
        }
    }
}
