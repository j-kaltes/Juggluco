package com.garmin.android.connectiq;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.garmin.android.connectiq.ConnectIQ;
import com.garmin.android.connectiq.IQDevice;
import com.garmin.monkeybrains.serialization.MonkeyArray;
import com.garmin.monkeybrains.serialization.MonkeyHash;
import com.garmin.monkeybrains.serialization.MonkeyType;
import com.garmin.monkeybrains.serialization.Serializer;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class IQMessageReceiver extends BroadcastReceiver {
    private static final int INVALID_APP_VERSION = 65535;
    private static final String sTAG = "IQMessageReceiver";
    private ConnectIQ.IQApplicationEventListener applistener;
    private ConnectIQ.IQDeviceEventListener listener;

    public IQMessageReceiver() {
        setListener((ConnectIQ.IQDeviceEventListener) null);
        setAppListener((ConnectIQ.IQApplicationEventListener) null);
    }

    public IQMessageReceiver(ConnectIQ.IQDeviceEventListener listener2, ConnectIQ.IQApplicationEventListener applistener2) {
        setListener(listener2);
        setAppListener(applistener2);
    }

    public void setListener(ConnectIQ.IQDeviceEventListener listener2) {
        this.listener = listener2;
    }

    public void setAppListener(ConnectIQ.IQApplicationEventListener applistener2) {
        this.applistener = applistener2;
    }

    public ConnectIQ.IQDeviceEventListener getListener() {
        return this.listener;
    }

    public ConnectIQ.IQApplicationEventListener getAppListener() {
        return this.applistener;
    }

    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(ConnectIQ.INCOMING_MESSAGE)) {
            IQDevice device = (IQDevice) intent.getParcelableExtra(ConnectIQ.EXTRA_REMOTE_DEVICE);
            IQApp app = (IQApp) intent.getParcelableExtra(ConnectIQ.EXTRA_REMOTE_APPLICATION);
            byte[] bytes = intent.getByteArrayExtra(ConnectIQ.EXTRA_PAYLOAD);
            if (bytes == null && this.applistener != null) {
                this.applistener.onMessageReceived(device, app, (List<Object>) null, ConnectIQ.IQMessageStatus.FAILURE_UNKNOWN);
            }
            try {
                List<MonkeyType<?>> data = Serializer.deserialize(bytes);
                List<Object> javaData = new ArrayList<>();
                for (MonkeyType<?> obj : data) {
                    javaData.add(convertToJava(obj));
                }
                if (this.applistener != null) {
                    this.applistener.onMessageReceived(device, app, javaData, ConnectIQ.IQMessageStatus.SUCCESS);
                }
            } catch (UnsupportedEncodingException e) {
                Log.e("RemoteMessageReceiver", "Error deserializing message", e);
                if (this.applistener != null) {
                    this.applistener.onMessageReceived(device, app, (List<Object>) null, ConnectIQ.IQMessageStatus.FAILURE_INVALID_FORMAT);
                }
            }
	   catch( Throwable  error) {
		String mess=error.getMessage();
		if(mess==null) {
			mess="OnReceive Exception";
			}
	       Log.e("IQMessageReceiver",mess);
                if (this.applistener != null) {
                	this.applistener.onMessageReceived(device, app, (List<Object>) null, ConnectIQ.IQMessageStatus.FAILURE_UNKNOWN);
                }
	   }
       
        } else if (intent.getAction().equals(ConnectIQ.DEVICE_STATUS)) {
            IQDevice device2 = (IQDevice) intent.getParcelableExtra(ConnectIQ.EXTRA_REMOTE_DEVICE);
            int status = intent.getIntExtra(ConnectIQ.EXTRA_STATUS, IQDevice.IQDeviceStatus.UNKNOWN.ordinal());
            IQDevice.IQDeviceStatus deviceStatus = IQDevice.IQDeviceStatus.UNKNOWN;
            try {
                deviceStatus = IQDevice.IQDeviceStatus.values()[status];
            } catch (IndexOutOfBoundsException e2) {
            }
            if (this.listener != null) {
                this.listener.onDeviceStatusChanged(device2, deviceStatus);
            }
        } else if (intent.getAction().equals(ConnectIQ.APPLICATION_INFO)) {
            String appId = intent.getStringExtra(ConnectIQ.EXTRA_APPLICATION_ID);
            int version = intent.getIntExtra(ConnectIQ.EXTRA_APPLICATION_VERSION, INVALID_APP_VERSION);
            if (ConnectIQStateManager.getInstance().getApplicationInfoListener() == null) {
                return;
            }
            if (appId == null || version < 0 || INVALID_APP_VERSION == version) {
                ConnectIQStateManager.getInstance().getApplicationInfoListener().onApplicationNotInstalled(appId);
            } else {
                ConnectIQStateManager.getInstance().getApplicationInfoListener().onApplicationInfoReceived(new IQApp(appId, version));
            }
        } else if (intent.getAction().equals(ConnectIQ.OPEN_APPLICATION)) {

           // long deviceId = intent.getLongExtra(ConnectIQ.EXTRA_OPEN_APPLICATION_DEVICE, 0);
            Bundle bun=intent.getExtras();
            IQDevice device2 ;
            bunnull:
            {
                Object IQobj=(long)0;
                if (bun != null) {
                    IQobj =bun.get(ConnectIQ.EXTRA_OPEN_APPLICATION_DEVICE);
                    if(IQobj instanceof IQDevice) {
                        device2 = (IQDevice) IQobj;
                        break bunnull;
                    }
                    else {
                        if(!(IQobj instanceof Long)) {
                            IQobj=0;
                        }

                    }
                }
                device2=new IQDevice((long)IQobj, BuildConfig.FLAVOR);
            }






            String appId2 = intent.getStringExtra(ConnectIQ.EXTRA_OPEN_APPLICATION_ID);
            int resultCode = intent.getIntExtra(ConnectIQ.EXTRA_OPEN_APPLICATION_RESULT_CODE, -1);
            if (ConnectIQStateManager.getInstance().getOpenApplicationListener() != null && appId2 != null && resultCode >= 0) {
                ConnectIQStateManager.getInstance().getOpenApplicationListener().onOpenApplicationResponse(device2, new IQApp(appId2), ConnectIQ.IQOpenApplicationStatus.fromInt(resultCode));
            }
        } else if (intent.getAction().equals(ConnectIQ.SEND_MESSAGE_STATUS)) {
            int statusValue = intent.getIntExtra(ConnectIQ.EXTRA_STATUS, 0);
            //long unitId = intent.getLongExtra(ConnectIQ.EXTRA_REMOTE_DEVICE, 0);

            Bundle bun=intent.getExtras();
            IQDevice device2 ;
            bunnull:
            {
                Object IQobj=(long)0;
                if (bun != null) {
                    IQobj =bun.get(ConnectIQ.EXTRA_REMOTE_DEVICE);
                    if(IQobj instanceof IQDevice) {
                        device2 = (IQDevice) IQobj;
                        break bunnull;
                    }
                    else {
                        if(!(IQobj instanceof Long)) {
                            IQobj=0;
                        }

                    }
                }
                device2=new IQDevice((long)IQobj, BuildConfig.FLAVOR);
            }








            String appId3 = intent.getStringExtra(ConnectIQ.EXTRA_APPLICATION_ID);
            if (ConnectIQStateManager.getInstance().getSendMessageListener() != null) {



                ConnectIQStateManager.getInstance().getSendMessageListener().onMessageStatus(device2, new IQApp(appId3), statusValue == 0 ? ConnectIQ.IQMessageStatus.SUCCESS : ConnectIQ.IQMessageStatus.FAILURE_DURING_TRANSFER);
            }
        }
    }

    private Object convertToJava(MonkeyType<?> object) {
        switch (object.mType) {
            case BuildConfig.VERSION_CODE:
            case 2:
            case 3:
            case 9:
            case 14:
            case 15:
            case 19:
                return object.toJava();
            case 5:
                List<MonkeyType<?>> iqArray = ((MonkeyArray) object).toJava();
                List<Object> javaArray = new ArrayList<>();
                for (MonkeyType<?> obj : iqArray) {
                    javaArray.add(convertToJava(obj));
                }
                return javaArray;
            case 11:
                HashMap<MonkeyType<?>, MonkeyType<?>> iqHash = ((MonkeyHash) object).toJava();
                HashMap<Object, Object> javaHash = new HashMap<>();
                for (MonkeyType<?> key : iqHash.keySet()) {
                    javaHash.put(convertToJava(key), convertToJava(iqHash.get(key)));
                }
                return javaHash;
            default:
                return null;
        }
    }
}
