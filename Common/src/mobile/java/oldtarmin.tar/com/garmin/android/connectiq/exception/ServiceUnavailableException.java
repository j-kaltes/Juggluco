package com.garmin.android.connectiq.exception;

public class ServiceUnavailableException extends Exception {
    private static final long serialVersionUID = 1;

    public ServiceUnavailableException(String message) {
        super(message);
    }
}
