package com.garmin.android.connectiq;

import android.os.Parcel;
import android.os.Parcelable;

public class IQDevice implements Parcelable {
    public static final Parcelable.Creator<IQDevice> CREATOR = new Parcelable.Creator<IQDevice>() {
        public IQDevice createFromParcel(Parcel in) {
            return new IQDevice(in);
        }

        public IQDevice[] newArray(int size) {
            return new IQDevice[size];
        }
    };
    private long deviceIdentifier;
    private String friendlyName;
    private IQDeviceStatus status = IQDeviceStatus.UNKNOWN;

    public enum IQDeviceStatus {
        NOT_PAIRED,
        NOT_CONNECTED,
        CONNECTED,
        UNKNOWN
    }

    public IQDevice(long deviceIdentifier2, String friendlyName2) {
        this.deviceIdentifier = deviceIdentifier2;
        this.friendlyName = friendlyName2;
    }

    public IQDevice(Parcel in) {
        this.deviceIdentifier = in.readLong();
        this.friendlyName = in.readString();
        try {
            this.status = IQDeviceStatus.valueOf(in.readString());
        } catch (IllegalArgumentException e) {
            this.status = IQDeviceStatus.UNKNOWN;
        }
    }

    public String getFriendlyName() {
        return this.friendlyName;
    }

    public long getDeviceIdentifier() {
        return this.deviceIdentifier;
    }

    public void setStatus(IQDeviceStatus status2) {
        this.status = status2;
    }

    public IQDeviceStatus getStatus() {
        return this.status;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.deviceIdentifier);
        dest.writeString(this.friendlyName);
        dest.writeString(this.status.name());
    }

    public String toString() {
        return this.friendlyName;
    }
}
