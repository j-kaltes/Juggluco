package com.garmin.android.connectiq;

import android.os.Parcel;
import android.os.Parcelable;

public class IQApp implements Parcelable {
    public static final Parcelable.Creator<IQApp> CREATOR = new Parcelable.Creator<IQApp>() {
        public IQApp createFromParcel(Parcel in) {
            return new IQApp(in);
        }

        public IQApp[] newArray(int size) {
            return new IQApp[size];
        }
    };
    private String applicationID;
    private String displayName;
    private IQAppStatus status;
    private int version;

    public enum IQAppStatus {
        UNKNOWN,
        INSTALLED,
        NOT_INSTALLED,
        NOT_SUPPORTED
    }

    public IQApp(String applicationID2) {
        this.applicationID = applicationID2.replaceAll("[\\s\\-]", BuildConfig.FLAVOR);
        this.status = IQAppStatus.UNKNOWN;
        this.displayName = BuildConfig.FLAVOR;
        this.version = 0;
    }

    public IQApp(String applicationID2, String displayName2, int version2) {
        this(applicationID2.replaceAll("[\\s\\-]", BuildConfig.FLAVOR), IQAppStatus.UNKNOWN, displayName2, version2);
    }

    public IQApp(String applicationID2, IQAppStatus status2, String displayName2, int version2) {
        this.applicationID = applicationID2.replaceAll("[\\s\\-]", BuildConfig.FLAVOR);
        this.status = status2;
        this.displayName = displayName2;
        this.version = version2;
    }

    public IQApp(String applicationID2, int version2) {
        this(applicationID2.replaceAll("[\\s\\-]", BuildConfig.FLAVOR), IQAppStatus.INSTALLED, BuildConfig.FLAVOR, version2);
    }

    public IQApp(Parcel in) {
        this.version = in.readInt();
        try {
            this.status = IQAppStatus.values()[in.readInt()];
        } catch (IndexOutOfBoundsException e) {
            this.status = IQAppStatus.UNKNOWN;
        }
        this.applicationID = in.readString();
        this.displayName = in.readString();
    }

    public String getApplicationId() {
        return this.applicationID;
    }

    public IQAppStatus getStatus() {
        return this.status;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public int version() {
        return this.version;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.version);
        dest.writeInt(this.status.ordinal());
        dest.writeString(this.applicationID);
        dest.writeString(this.displayName);
    }

    public String toString() {
        return this.displayName;
    }
}
