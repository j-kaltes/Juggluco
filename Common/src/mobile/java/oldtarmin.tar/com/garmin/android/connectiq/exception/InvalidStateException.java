package com.garmin.android.connectiq.exception;

public class InvalidStateException extends Exception {
    private static final long serialVersionUID = 1;

    public InvalidStateException(String message) {
        super(message);
    }
}
