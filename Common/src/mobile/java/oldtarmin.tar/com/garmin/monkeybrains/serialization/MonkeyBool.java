package com.garmin.monkeybrains.serialization;

import java.nio.ByteBuffer;

public class MonkeyBool extends MonkeyType<Boolean> {
    private boolean mValue;

    public MonkeyBool(boolean bool) {
        super((byte) 9);
        this.mValue = bool;
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public MonkeyBool(byte[] bytes) {
        super(bytes[0]);
        boolean z = true;
        this.mValue = ByteBuffer.wrap(bytes, 1, bytes.length + -1).get() <= 0 ? false : z;
    }

    public int getNumBytes() {
        return 2;
    }

    public byte[] serialize() {
        int i = 0;
        byte[] bArr = new byte[2];
        bArr[0] = 9;
        if (this.mValue) {
            i = 1;
        }
        bArr[1] = (byte) i;
        return bArr;
    }

    public Boolean toJava() {
        return new Boolean(this.mValue);
    }
}
