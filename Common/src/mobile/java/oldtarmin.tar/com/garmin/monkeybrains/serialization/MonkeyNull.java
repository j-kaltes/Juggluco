package com.garmin.monkeybrains.serialization;

public class MonkeyNull extends MonkeyType<Object> {
    public MonkeyNull() {
        super((byte) 0);
    }

    public MonkeyNull(Object obj) {
        super((byte) 0);
    }

    public MonkeyNull(byte[] bytes) {
        super((byte) 0);
    }

    public int getNumBytes() {
        return 1;
    }

    public byte[] serialize() {
        return new byte[]{0};
    }

    public Object toJava() {
        return null;
    }
}
