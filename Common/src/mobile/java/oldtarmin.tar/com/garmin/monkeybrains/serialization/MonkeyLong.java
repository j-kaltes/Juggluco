package com.garmin.monkeybrains.serialization;

import java.nio.ByteBuffer;

public class MonkeyLong extends MonkeyType<Long> {
    private long mValue;

    public MonkeyLong(long value) {
        super(MonkeyType.LONG);
        this.mValue = value;
    }

    public MonkeyLong(byte[] bytes) {
        super(bytes[0]);
        this.mValue = ByteBuffer.wrap(bytes, 1, bytes.length - 1).getLong();
    }

    public int getNumBytes() {
        return 9;
    }

    public byte[] serialize() {
        ByteBuffer bb = ByteBuffer.allocate(getNumBytes());
        bb.put(MonkeyType.LONG);
        bb.putLong(this.mValue);
        return bb.array();
    }

    public Long toJava() {
        return new Long(this.mValue);
    }
}
