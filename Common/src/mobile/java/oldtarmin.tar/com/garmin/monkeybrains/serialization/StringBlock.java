package com.garmin.monkeybrains.serialization;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class StringBlock extends ArrayList<MonkeyString> {
    private static final long serialVersionUID = 7158590947509522494L;
    private HashMap<Integer, String> mDeserializedStrings;
    private int mTotalBytes;

    public StringBlock() {
    }

    public StringBlock(byte[] bytes) throws UnsupportedEncodingException {
        this.mDeserializedStrings = new HashMap<>();
        int size = bytes.length;
        int i = 0;
        while (i < size) {
            int offset = i;
            int stringSize = ByteBuffer.wrap(bytes, i, 2).getShort();
            int i2 = i + 2;
            byte[] stringBytes = Arrays.copyOfRange(bytes, i2, (i2 + stringSize) - 1);
            i = i2 + stringSize;
            this.mDeserializedStrings.put(new Integer(offset), new String(stringBytes, "UTF-8"));
        }
    }

    public int addString(MonkeyString type) throws UnsupportedEncodingException {
        int offset = getOffsetFor(type);
        type.setOffset(offset);
        if (!contains(type)) {
            add(type);
            this.mTotalBytes += type.getValue().getBytes("UTF-8").length + 2 + 1;
        }
        return offset;
    }

    private int getOffsetFor(MonkeyString aString) throws UnsupportedEncodingException {
        int offset = 0;
        int i = 0;
        while (i < size() && !((MonkeyString) get(i)).equals(aString)) {
            offset += ((MonkeyString) get(i)).getValue().getBytes("UTF-8").length + 2 + 1;
            i++;
        }
        return offset;
    }

    public byte[] serialize() throws UnsupportedEncodingException {
        ByteBuffer bb = ByteBuffer.allocate(this.mTotalBytes);
        for (int i = 0; i < size(); i++) {
            bb.put(((MonkeyString) get(i)).serializeString());
        }
        return bb.array();
    }

    public HashMap<Integer, String> getDeserializedStrings() {
        return this.mDeserializedStrings;
    }
}
