package com.garmin.monkeybrains.serialization;

import java.nio.ByteBuffer;

public class MonkeyFloat extends MonkeyType<Float> {
    private float mValue;

    public MonkeyFloat(float value) {
        super((byte) 2);
        this.mValue = value;
    }

    public MonkeyFloat(byte[] bytes) {
        super(bytes[0]);
        this.mValue = ByteBuffer.wrap(bytes, 1, bytes.length - 1).getFloat();
    }

    public int getNumBytes() {
        return 5;
    }

    public byte[] serialize() {
        ByteBuffer bb = ByteBuffer.allocate(getNumBytes());
        bb.put((byte) 2);
        bb.putFloat(this.mValue);
        return bb.array();
    }

    public Float toJava() {
        return new Float(this.mValue);
    }
}
