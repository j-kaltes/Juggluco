package com.garmin.monkeybrains.serialization;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

public class MonkeyArray extends MonkeyType<List<MonkeyType<?>>> implements MonkeyContainer {
    private int mChildCount;
    private List<MonkeyType<?>> mList = new ArrayList<>();

    public <T> MonkeyArray(List<T> list) {
        super((byte) 5);
        for (T obj : list) {
            this.mList.add(MonkeyType.fromJava(obj));
        }
    }

    public MonkeyArray(byte[] bytes) throws UnsupportedEncodingException {
        super(bytes[0]);
        this.mChildCount = ByteBuffer.wrap(bytes, 1, 4).getInt();
    }

    public int getNumBytes() {
        int numBytes = 5;
        for (MonkeyType<?> type : this.mList) {
            numBytes += type.getNumBytes();
        }
        return numBytes;
    }

    public byte[] serialize() {
        ByteBuffer bb = ByteBuffer.allocate(5);
        bb.put((byte) 5);
        bb.putInt(this.mList.size());
        return bb.array();
    }

    public List<MonkeyType<?>> toJava() {
        return this.mList;
    }

    public List<MonkeyType<?>> getValues() {
        return this.mList;
    }

    public List<MonkeyType<?>> getChildren() {
        return this.mList;
    }

    public int getChildCount() {
        return this.mChildCount;
    }
}
