package com.garmin.monkeybrains.serialization;

import java.nio.ByteBuffer;

public class MonkeyInt extends MonkeyType<Integer> {
    private int mValue;

    public MonkeyInt(int value) {
        super((byte) 1);
        this.mValue = value;
    }

    public MonkeyInt(byte[] bytes) {
        super(bytes[0]);
        this.mValue = ByteBuffer.wrap(bytes, 1, bytes.length - 1).getInt();
    }

    public int getNumBytes() {
        return 5;
    }

    public byte[] serialize() {
        ByteBuffer bb = ByteBuffer.allocate(getNumBytes());
        bb.put(this.mType);
        bb.putInt(this.mValue);
        return bb.array();
    }

    public Integer toJava() {
        return new Integer(this.mValue);
    }
}
