package com.garmin.monkeybrains.serialization;

import java.io.UnsupportedEncodingException;
import java.util.List;

public class Serializer {
    private SerializedObject mSerializedObject;

    public static List<MonkeyType<?>> deserialize(byte[] bytes) throws UnsupportedEncodingException {
        return new SerializedObject(bytes).getValues();
    }

    public static <T> byte[] serialize(T obj) throws Exception {
        return new Serializer(obj).serialize();
    }

    public Serializer() {
        this.mSerializedObject = new SerializedObject();
    }

    public Serializer(Object obj) throws UnsupportedEncodingException {
        this();
        addObject(obj);
    }

    public <T> void addObject(T obj) throws UnsupportedEncodingException {
        this.mSerializedObject.addObject(MonkeyType.fromJava(obj));
    }

    public byte[] serialize() throws Exception {
        return this.mSerializedObject.serialize();
    }
}
