package com.garmin.monkeybrains.serialization;

import java.nio.ByteBuffer;

public class MonkeyDouble extends MonkeyType<Double> {
    private double mValue;

    public MonkeyDouble(double value) {
        super(MonkeyType.DOUBLE);
        this.mValue = value;
    }

    public MonkeyDouble(byte[] bytes) {
        super(bytes[0]);
        this.mValue = ByteBuffer.wrap(bytes, 1, bytes.length - 1).getDouble();
    }

    public int getNumBytes() {
        return 9;
    }

    public byte[] serialize() {
        ByteBuffer bb = ByteBuffer.allocate(getNumBytes());
        bb.put(MonkeyType.DOUBLE);
        bb.putDouble(this.mValue);
        return bb.array();
    }

    public Double toJava() {
        return new Double(this.mValue);
    }
}
