package com.garmin.monkeybrains.serialization;

import java.nio.ByteBuffer;

public class MonkeyChar extends MonkeyType<Integer> {
    private Integer mValue;

    public MonkeyChar(Integer value) {
        super(MonkeyType.CHAR);
        this.mValue = value;
    }

    public MonkeyChar(byte[] bytes) {
        super(bytes[0]);
        this.mValue = Integer.valueOf(ByteBuffer.wrap(bytes, 1, bytes.length - 1).getInt());
    }

    public int getNumBytes() {
        return 5;
    }

    public byte[] serialize() {
        ByteBuffer bb = ByteBuffer.allocate(getNumBytes());
        bb.put(MonkeyType.CHAR);
        bb.putInt(this.mValue.intValue());
        return bb.array();
    }

    public Integer toJava() {
        return new Integer(this.mValue.intValue());
    }
}
