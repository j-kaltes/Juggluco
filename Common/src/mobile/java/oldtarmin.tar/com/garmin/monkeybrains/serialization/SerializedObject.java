package com.garmin.monkeybrains.serialization;

import android.util.Log;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class SerializedObject {
    private static final int DATA_BLOCK_SENTINEL = -629482886;
    private static final int STRING_BLOCK_SENTINEL = -1412584499;
    private DataBlock mDataBlock;
    private StringBlock mStringBlock;

    public SerializedObject() {
        this.mStringBlock = new StringBlock();
        this.mDataBlock = new DataBlock();
    }

    public SerializedObject(byte[] bytes) throws UnsupportedEncodingException {
        int stringBlockSize = getStringBlock(bytes);

        if (stringBlockSize > 0) {
            Log.i("SerializedObject","stringBlockSize="+ stringBlockSize);
            this.mStringBlock = new StringBlock(Arrays.copyOfRange(bytes, 8, stringBlockSize + 8));
        }
        int  dataBlockOffset= stringBlockSize == 0 ? 0 : stringBlockSize + 8;
        Log.i("SerializedObject","dataBlockOffset="+ dataBlockOffset);
        ByteBuffer bb = ByteBuffer.wrap(bytes, dataBlockOffset, 8);
        bb.getInt();
        this.mDataBlock = new DataBlock(Arrays.copyOfRange(bytes, dataBlockOffset + 8, dataBlockOffset + 8 + bb.getInt()), this.mStringBlock);
    }

    public void addObject(MonkeyType<?> type) throws UnsupportedEncodingException {
        this.mDataBlock.add(type);
        addToStrings(type);
    }

    private void addToStrings(MonkeyType<?> type) throws UnsupportedEncodingException {
        if (type instanceof MonkeyString) {
            ((MonkeyString) type).setOffset(this.mStringBlock.addString((MonkeyString) type));
        } else if (type instanceof MonkeyArray) {
            for (MonkeyType<?> t : ((MonkeyArray) type).getValues()) {
                addToStrings(t);
            }
        } else if (type instanceof MonkeyHash) {
            for (Map.Entry<MonkeyType<?>, MonkeyType<?>> entry : ((MonkeyHash) type).getHashMap().entrySet()) {
                addToStrings(entry.getKey());
                addToStrings(entry.getValue());
            }
        }
    }

    public byte[] serialize() throws Exception {
        int size;
        byte[] stringBytes = this.mStringBlock.serialize();
        byte[] dataBytes = this.mDataBlock.serialize();
        if (stringBytes.length > 0) {
            size = stringBytes.length + 8 + 4 + 4 + dataBytes.length;
        } else {
            size = dataBytes.length + 8;
        }
        ByteBuffer bb = ByteBuffer.allocate(size);
        if (stringBytes.length > 0) {
            bb.putInt(STRING_BLOCK_SENTINEL);
            bb.putInt(stringBytes.length);
            bb.put(stringBytes);
        }
        bb.putInt(DATA_BLOCK_SENTINEL);
        bb.putInt(dataBytes.length);
        bb.put(dataBytes);
        return bb.array();
    }

    private int getStringBlock(byte[] bytes) {
        ByteBuffer bb = ByteBuffer.wrap(bytes);
        if (bb.getInt() == STRING_BLOCK_SENTINEL) {
            return bb.getInt();
        }
        return 0;
    }

    public List<MonkeyType<?>> getValues() {
        return this.mDataBlock;
    }
}
