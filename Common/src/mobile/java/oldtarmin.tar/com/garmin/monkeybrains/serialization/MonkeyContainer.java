package com.garmin.monkeybrains.serialization;

import java.util.List;

public interface MonkeyContainer {
    int getChildCount();

    List<MonkeyType<?>> getChildren();
}
