package tk.glucodata.settings;

import android.app.Activity;
import android.content.Context;
import android.text.InputType;
import android.text.method.DigitsKeyListener;

import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import tk.glucodata.Applic;
import tk.glucodata.Layout;
import tk.glucodata.Log;
import tk.glucodata.MainActivity;
import tk.glucodata.Natives;
import tk.glucodata.R;

import static android.view.View.GONE;
import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static tk.glucodata.Applic.isWearable;
import static tk.glucodata.MainActivity.getscreenwidth;
import static tk.glucodata.help.hidekeyboard;
import static tk.glucodata.settings.Settings.editoptions;
import static tk.glucodata.settings.Settings.removeContentView;
import static tk.glucodata.util.getbutton;
import static tk.glucodata.util.getlabel;

public class LibreNumbers {
public void hideSystemUI(Context cont) {}

ViewGroup librenumberslistview=null;
Layout librenumberslist=null;

ArrayList<ArrayList<Object>> libreNumbers;
ArrayList<Object> current=null;

void addrow(Context act,int index) {
		ArrayList<Object>  el=libreNumbers.get(index); 
	 	Button lab=getbutton(act,(String)el.get(0));
		lab.setTransformationMethod(null);
           	lab.setOnClickListener(v->{
			current=el;
			mklibrenumbers((MainActivity)v.getContext());
			setvalues((String)el.get(0),(String)el.get(1));
			delete.setVisibility(VISIBLE);
		});

		lab.setMinEms(10);
		String values =  (String)el.get(1);
		TextView value=getlabel(act,values);
		value.setMinEms(4);
		librenumberslist.addrow(new View[]{lab,value});
		}
private static String LOG_ID="LibreNumbers";
void mklibrenumberslist(Context act) {

	libreNumbers= Natives.getShortcuts();
	 int len=libreNumbers.size();
	 Log.i(LOG_ID,"mklibrenumberslist "+len);
	 librenumberslist= new Layout(act,(l, w, h)->{

			return new int[] {w,h};
	 }, len);
	 for(int i=0;i<len;i++) {
	 	addrow(act,i);
	 	}
	}
void saveall(View v) {
	MainActivity main=(MainActivity) v.getContext();
	 if(librenumbersedit!=null)  {
		final int nr= libreNumbers.size();
		for(int i=0;i<nr;i++) {
			ArrayList<Object> el=libreNumbers.get(i);
			int ret;
			if((ret=Natives.setShortcut(i,(String)el.get(0),(String)el.get(1)))!=-1) {
				if(ret==-5)
					Toast.makeText(v.getContext(), "index "+i+" too large", Toast.LENGTH_SHORT).show();
				else
					Toast.makeText(v.getContext(), (String)el.get(ret)+" too long", Toast.LENGTH_SHORT).show();
				return;
				}
			}
		Natives.setnrlibreNumbers(nr);
		if(!isWearable) {
			((Applic)(((Activity)v.getContext()).getApplication())).numdata.sendlibreNumbers(libreNumbers);
			}
		 Applic.wakemirrors();
		 removeContentView(librenumbersedit);
		 }
	 removeContentView(librenumberslistview);
	main.poponback();
	}
public void mklibrenumberslistview(MainActivity act) {
	if(librenumberslistview==null) {
		Button add=new Button(act),ok=new Button(act);
		add.setText(R.string.newname);
           	add.setOnClickListener(v->{
			current=null;
			mklibrenumbers(act);
			setvalues("","");
			delete.setVisibility(INVISIBLE);
			});
		ok.setText(R.string.save);
           	ok.setOnClickListener(this::saveall);
		Button cancel=getbutton(act,R.string.cancel);
           	cancel.setOnClickListener(v->{
				act.doonback();
			});
		Button help=getbutton(act,R.string.helpname);
		help.setOnClickListener(v->{tk.glucodata.help.help(R.string.librenumberscuthelp,act); });
		ScrollView scroll=new ScrollView(act);
		scroll.setSmoothScrollingEnabled(false);
		scroll.setVerticalScrollBarEnabled(false);
		scroll.setHorizontalScrollBarEnabled(false);
		
		scroll.setLayoutParams(new ViewGroup.LayoutParams(   ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
		mklibrenumberslist(act);
		scroll.addView(librenumberslist);
		Layout butview= new Layout(act,new View[]{add},new View[]{help},new View[]{cancel},new View[]{ok});
		butview.setLayoutParams(new ViewGroup.LayoutParams(   ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT));
		librenumberslistview= new Layout(act,(a,w,h)->{
			hideSystemUI(act);
			return new int[] {w,h}; },new View[]{scroll,butview});
		librenumberslistview.setBackgroundColor(tk.glucodata.Applic.backgroundcolor);
		act.addContentView(librenumberslistview, new ViewGroup.LayoutParams(MATCH_PARENT, MATCH_PARENT));
		}
	else {
        	librenumberslistview.setVisibility(VISIBLE);
		}
	Runnable closerun=() -> {
		librenumberslistview.setVisibility(GONE);
		if(librenumbersedit!=null)
			removeContentView(librenumbersedit);
		removeContentView(librenumberslistview);
		};
	act.setonback(closerun);
	}
ViewGroup librenumbersedit=null;
EditText labedit=null, valedit=null;
void deletelibrenumbers(View v) {
	int index=libreNumbers.indexOf(current);
	if(index>=0) {
		libreNumbers.remove(index);
		librenumberslist.delrow(index);
		}
	 endlibrenumbersedit() ;
	 ((MainActivity)v.getContext()).poponback();
	}
void endlibrenumbersedit() {
	librenumbersedit.setVisibility(GONE);
	hidekeyboard((Activity)librenumbersedit.getContext()); //USE
	}
void savelibrenumbers(View v) {
	String label=labedit.getText().toString();
	String values=valedit.getText().toString();
	if(current==null) {
		ArrayList<Object> el=new ArrayList<>();
		el.add(label);
		el.add(values);
		libreNumbers.add(el);
		addrow(v.getContext(),libreNumbers.size()-1);
		current=el;
		}
	else {
		int index=libreNumbers.indexOf(current);
		if(index>=0) {
			current.set(0,label);
			current.set(1,values);
			View[] views=librenumberslist.getrow(index);
			((TextView)views[0]).setText(label);
			((TextView)views[1]).setText(values);
			}
		}
	
	 endlibrenumbersedit() ;
	 ((MainActivity)v.getContext()).poponback();
	}
void setvalues(String name,String value) {
	labedit.setText(name);
	valedit.setText(value);
	}
Button delete=null;
void mklibrenumbers(MainActivity act) {
if(librenumbersedit==null) {
	TextView label=getlabel(act,R.string.librenumberscut);
	labedit=new EditText(act);
	labedit.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);

	labedit.setImeOptions( EditorInfo.IME_FLAG_NO_EXTRACT_UI| EditorInfo.IME_FLAG_NO_FULLSCREEN| EditorInfo.IME_ACTION_DONE);
	labedit.setMinEms(7);
	TextView value=getlabel(act,R.string.value);
	valedit=new EditText(act);
	valedit.setMinEms(3);
	valedit.setInputType(InputType.TYPE_CLASS_NUMBER |InputType.TYPE_NUMBER_FLAG_DECIMAL);//| InputType.IME_FLAG_NO_FULLSCREEN);

        valedit.setImeOptions(editoptions);
	Button save=getbutton(act,R.string.ok);
	save.setOnClickListener(this::savelibrenumbers);
	delete=getbutton(act,R.string.delete);
	delete.setOnClickListener(this::deletelibrenumbers);
	Button cancel=getbutton(act,R.string.cancel);
	cancel.setOnClickListener(v->{ 
			act.doonback();
			 }); 
	librenumbersedit=new Layout(act, (l, w, h) -> {
			hideSystemUI(act);
			var width= getscreenwidth(act);
			if(width>w)
			    l.setX(( width- w)* 0.7f);
			    l.setY(0);

			return new int[] {w,h};
			    }, new View[] {label,labedit},new View[] {value,valedit},new View[] {delete,cancel,save});

	      librenumbersedit.setBackgroundResource(R.drawable.dialogbackground);
	   int pad=(int)(tk.glucodata.GlucoseCurve.metrics.density*5.0);
	   librenumbersedit.setPadding(pad,0,pad,0);
	act.addContentView(librenumbersedit, new ViewGroup.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
    }
    else {
        librenumbersedit.setVisibility(VISIBLE);
	}
   act.setonback(() -> endlibrenumbersedit() );
   }
   }
